### Adding a New Icon? 
- Add `?quick_pull=1&template=new_icon.md` to the end of your current URL and press `Enter`

### Adding a New Feature or fixing a bug? 
- Add `?quick_pull=1&template=new_feature.md` to the end of your current URL and press `Enter`.