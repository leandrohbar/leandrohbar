## Double check these details before you open a PR

<!-- Tick the checkboxes to ensure you've done everything correctly -->
- [ ] PR does not match another non-stale PR currently opened

## Features
<!-- List your features here and the benefits they bring. Include images/codes as appropriate -->

**This PR closes NONE**
<!-- List issues that this PR would close above. Ex: This PR closes #1, #2, #3. -->

## Notes
<!-- List anything note-worthy here (potential issues, this needs to be merged to `master` before working, etc.). -->
